/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hospitalpatientadmissionsystem;

/**
 *
 * @author rikha
 */
import java.util.Scanner;
import java.util.InputMismatchException;

public class HospitalPatientAdmissionSystem {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        HospitalSystem hospital = new HospitalSystem();

        int choice = -1;

        do {
            System.out.println(" MEDICARE HOSPITAL ADMISSION SYSTEM");
           
            System.out.println("1. Register Patient");
            System.out.println("2. Search Patient");
            System.out.println("3. Update Patient");
            System.out.println("4. Delete Patient");
            System.out.println("5. Display All Patients");
            System.out.println("6. Allocate Bed");
            System.out.println("7. Release Bed");
            System.out.println("8. Display Ward Layout");
            System.out.println("9. Display Available Beds");
            System.out.println("10. Display Occupied Beds");
            System.out.println("11. Generate Report");
            System.out.println("12. Sort Patients by Surname");
            System.out.println("13. Sort Patients by Patient ID");
            System.out.println("0. Exit");

            try {

                System.out.print("\nEnter your choice: ");

                choice = input.nextInt();

                input.nextLine();

                switch (choice) {

                    case 1:

                        registerPatient(input, hospital);

                        break;

                    case 2:

                        searchPatient(input, hospital);

                        break;

                    case 3:

                        updatePatient(input, hospital);

                        break;

                    case 4:

                        deletePatient(input, hospital);

                        break;

                    case 5:

                        hospital.displayAllPatients();

                        break;

                    case 6:

                        allocateBed(input, hospital);

                        break;

                    case 7:

                        releaseBed(input, hospital);

                        break;

                    case 8:

                        hospital.displayWardLayout();

                        break;

                    case 9:

                        hospital.displayAvailableBeds();

                        break;

                    case 10:

                        hospital.displayOccupiedBeds();

                        break;

                    case 11:

                        hospital.generateReport();

                        break;

                    case 12:

                        hospital.sortBySurname();

                        System.out.println(
                                "Patients sorted by surname."
                        );

                        hospital.displayAllPatients();

                        break;

                    case 13:

                        hospital.sortByPatientId();

                        System.out.println(
                                "Patients sorted by Patient ID."
                        );

                        hospital.displayAllPatients();

                        break;

                    case 0:

                        System.out.println(
                                "Thank you for using the system."
                        );

                        break;

                    default:

                        System.out.println(
                                "Invalid choice."
                        );
                }

            } catch (InputMismatchException e) {

                System.out.println(
                        "Please enter a valid number."
                );

                input.nextLine();
            }

        } while (choice != 0);

        input.close();
    }

    
    // REGISTER PATIENT
    
    public static void registerPatient(
            Scanner input,
            HospitalSystem hospital) {

        System.out.println("\n===== REGISTER PATIENT =====");

        System.out.print("Patient ID: ");
        String id = input.nextLine();

        // Prevent duplicate ID
        if (hospital.searchPatient(id) != null) {

            System.out.println(
                    "Patient ID already exists."
            );

            return;
        }

        System.out.print("First Name: ");
        String firstName = input.nextLine();

        System.out.print("Last Name: ");
        String lastName = input.nextLine();

        System.out.print("Age: ");
        int age = input.nextInt();

        input.nextLine();

        System.out.print("Gender: ");
        String gender = input.nextLine();

        System.out.print("Medical Condition: ");
        String condition = input.nextLine();

        PatientCategory category =
                chooseCategory(input);

        patient p;

        if (category == PatientCategory.INPATIENT) {

            System.out.print("Ward Number: ");
            String ward = input.nextLine();

            p = new inpatient(
                    id,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    ward,
                    "Not Allocated"
            );

        } else {

            p = new patient(
                    id,
                    firstName,
                    lastName,
                    age,
                    gender,
                    condition,
                    category
            );
        }

        if (hospital.registerPatient(p)) {

            System.out.println(
                    "Patient registered successfully."
            );

        } else {

            System.out.println(
                    "Patient registration failed."
            );
        }
    }

    
    // CHOOSE CATEGORY

    public static PatientCategory chooseCategory(
            Scanner input) {

        System.out.println("\nPatient Category");

        System.out.println("1. Inpatient");
        System.out.println("2. Outpatient");
        System.out.println("3. Emergency");

        System.out.print("Choose category: ");

        int choice = input.nextInt();

        input.nextLine();

        switch (choice) {

            case 1:
                return PatientCategory.INPATIENT;

            case 2:
                return PatientCategory.OUTPATIENT;

            case 3:
                return PatientCategory.EMERGENCY;

            default:

                System.out.println(
                        "Invalid category. Outpatient selected."
                );

                return PatientCategory.OUTPATIENT;
        }
    }


      // SEARCH PATIENT
    public static void searchPatient(
            Scanner input,
            HospitalSystem hospital) {

        System.out.print(
                "\nEnter Patient ID: "
        );

        String id = input.nextLine();

        patient p = hospital.searchPatient(id);

        if (p != null) {

            System.out.println(
                    "\nPATIENT FOUND"
            );

            p.displayDetails();

        } else {

            System.out.println(
                    "Patient not found."
            );
        }
    }


    // UPDATE PATIENT
    
    public static void updatePatient(
            Scanner input,
            HospitalSystem hospital) {

        System.out.print(
                "\nEnter Patient ID: "
        );

        String id = input.nextLine();

        patient p = hospital.searchPatient(id);

        if (p == null) {

            System.out.println(
                    "Patient not found."
            );

            return;
        }

        System.out.print("New First Name: ");
        String firstName = input.nextLine();

        System.out.print("New Last Name: ");
        String lastName = input.nextLine();

        System.out.print("New Age: ");
        int age = input.nextInt();

        input.nextLine();

        System.out.print("New Gender: ");
        String gender = input.nextLine();

        System.out.print(
                "New Medical Condition: "
        );

        String condition = input.nextLine();

        PatientCategory category =
                chooseCategory(input);

        boolean updated =
                hospital.updatePatient(
                        id,
                        firstName,
                        lastName,
                        age,
                        gender,
                        condition,
                        category
                );

        if (updated) {

            System.out.println(
                    "Patient updated successfully."
            );

        } else {

            System.out.println(
                    "Patient update failed."
            );
        }
    }

    
    // DELETE PATIENT
   
    public static void deletePatient(
            Scanner input,
            HospitalSystem hospital) {

        System.out.print(
                "\nEnter Patient ID to delete: "
        );

        String id = input.nextLine();

        if (hospital.deletePatient(id)) {

            System.out.println(
                    "Patient deleted successfully."
            );

        } else {

            System.out.println(
                    "Patient not found."
            );
        }
    }

    
    // ALLOCATE BED
    
    public static void allocateBed(
            Scanner input,
            HospitalSystem hospital) {

        System.out.print(
                "\nEnter Inpatient ID: "
        );

        String id = input.nextLine();

        patient p = hospital.searchPatient(id);

        if (p == null) {

            System.out.println(
                    "Patient not found."
            );

            return;
        }

        if (!(p instanceof inpatient)) {

            System.out.println(
                    "Only inpatients can be allocated a bed."
            );

            return;
        }

        hospital.displayAvailableBeds();

        System.out.print(
                "Enter bed number: "
        );

        String bed = input.nextLine();

        if (hospital.allocateBed(id, bed)) {

            System.out.println(
                    "Bed allocated successfully."
            );

        } else {

            System.out.println(
                    "Bed allocation failed."
            );
        }
    }

    
    // RELEASE BED
    
    public static void releaseBed(
            Scanner input,
            HospitalSystem hospital) {

        System.out.print(
                "\nEnter bed number: "
        );

        String bed = input.nextLine();

        if (hospital.releaseBed(bed)) {

            System.out.println(
                    "Bed released successfully."
            );

        } else {

            System.out.println(
                    "Bed could not be released."
            );
        }
    }
}

