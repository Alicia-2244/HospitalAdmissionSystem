/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalpatientadmissionsystem;

/**
 *
 * @author rikha
 */
public class patient {
     // Fields
    String patientId;
    String firstName;
    String lastName;
    int age;
    String gender;
    String medicalCondition;
    PatientCategory category;

    // Constructor
    public patient(String patientId, String firstName, String lastName,
                   int age, String gender, String medicalCondition,
                   PatientCategory category) {

        this.patientId = patientId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.gender = gender;
        this.medicalCondition = medicalCondition;
        this.category = category;
    }

    // Getter
    public String getPatientId() {
        return patientId;
    }

    // Getter
    public String getFirstName() {
        return firstName;
    }

    // Getter
    public String getLastName() {
        return lastName;
    }

    // Getter
    public int getAge() {
        return age;
    }

    // Getter
    public String getGender() {
        return gender;
    }

    // Getter
    public String getMedicalCondition() {
        return medicalCondition;
    }

    // Getter
    public PatientCategory getCategory() {
        return category;
    }

    // Setter
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    // Setter
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    // Setter
    public void setAge(int age) {
        this.age = age;
    }

    // Setter
    public void setGender(String gender) {
        this.gender = gender;
    }

    // Setter
    public void setMedicalCondition(String medicalCondition) {
        this.medicalCondition = medicalCondition;
    }

    // Setter
    public void setCategory(PatientCategory category) {
        this.category = category;
    }

    // Method
    public void displayDetails() {

        System.out.println("Patient ID: " + patientId);
        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("Age: " + age);
        System.out.println("Gender: " + gender);
        System.out.println("Medical Condition: " + medicalCondition);
        System.out.println("Category: " + category);
    }
}
    

