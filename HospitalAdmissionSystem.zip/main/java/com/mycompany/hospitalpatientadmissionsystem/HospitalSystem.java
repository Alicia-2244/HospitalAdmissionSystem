/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hospitalpatientadmissionsystem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 * @author rikha
 */
public class HospitalSystem {

    // Patient list
    ArrayList<patient> patients;

    // 4 rows and 5 columns = 20 beds
    String[][] beds;

    // Constructor
    public HospitalSystem() {

        patients = new ArrayList<>();

        beds = new String[4][5];

        createBeds();
    }

 
    // BED CREATION
    

    public void createBeds() {

        int number = 1;

        for (int row = 0; row < 4; row++) {

            for (int column = 0; column < 5; column++) {

                beds[row][column] =
                        "B" + String.format("%02d", number);

                number++;
            }
        }
    }

    
    // PATIENT MANAGEMENT
    

    // Register patient

    public boolean registerPatient(patient p) {

        if (searchPatient(p.getPatientId()) != null) {

            return false;
        }

        patients.add(p);

        return true;
    }

    // Search patient

    public patient searchPatient(String patientId) {

        for (patient p : patients) {

            if (p.getPatientId().equalsIgnoreCase(patientId)) {

                return p;
            }
        }

        return null;
    }

    // Update patient

    public boolean updatePatient(String patientId,
                                 String firstName,
                                 String lastName,
                                 int age,
                                 String gender,
                                 String medicalCondition,
                                 PatientCategory category) {

        patient p = searchPatient(patientId);

        if (p == null) {

            return false;
        }

        p.setFirstName(firstName);
        p.setLastName(lastName);
        p.setAge(age);
        p.setGender(gender);
        p.setMedicalCondition(medicalCondition);
        p.setCategory(category);

        return true;
    }

    // Delete patient

    public boolean deletePatient(String patientId) {

        patient p = searchPatient(patientId);

        if (p == null) {

            return false;
        }

        if (p instanceof inpatient) {

            inpatient in = (inpatient) p;

            if (!in.getBedNumber().equals("Not Allocated")) {

                releaseBed(in.getBedNumber());
            }
        } 
            
        patients.remove(p);

        return true;
    }

    // Display all patients

    public void displayAllPatients() {

        if (patients.isEmpty()) {

            System.out.println("No patients registered.");

            return;
        }

        System.out.println("\n ALL PATIENTS");

        for (patient p : patients) {

            p.displayDetails();

            
        }
    }

    
    // BED MANAGEMENT
    

    // Find a bed

    public int[] findBed(String bedNumber) {

        for (int row = 0; row < beds.length; row++) {

            for (int column = 0;
                 column < beds[row].length;
                 column++) {

                if (beds[row][column]
                        .equalsIgnoreCase(bedNumber)) {

                    return new int[]{row, column};
                }
            }
        }

        return null;
    }

    // Allocate bed

    public boolean allocateBed(String patientId,
                               String bedNumber) {

        patient p = searchPatient(patientId);

        if (p == null) {

            return false;
        }

        if (!(p instanceof inpatient)) {

            return false;
        }

        int[] position = findBed(bedNumber);

        if (position == null) {

            return false;
        }

        // Check if bed is occupied

        if (beds[position[0]][position[1]].contains(":")) {

            return false;
        }

        inpatient in = (inpatient) p;

        // Check if patient already has a bed

        if (!in.getBedNumber().equals("Not Allocated")) {

            return false;
        }

        beds[position[0]][position[1]] =
                bedNumber + ":" + patientId;

        in.setBedNumber(bedNumber);

        return true;
    }

    // Release bed

    public boolean releaseBed(String bedNumber) {

        int[] position = findBed(bedNumber);

        if (position == null) {

            return false;
        }

        if (!beds[position[0]][position[1]].contains(":")) {

            return false;
        }

        String occupiedBed =
                beds[position[0]][position[1]];

        String patientId =
                occupiedBed.substring(
                        occupiedBed.indexOf(":") + 1);

        beds[position[0]][position[1]] = bedNumber;

        patient p = searchPatient(patientId);

        if (p instanceof inpatient) {

            inpatient in = (inpatient) p;

            in.setBedNumber("Not Allocated");
        }

        return true;
    }

    // Display ward layout

    public void displayWardLayout() {

        System.out.println("\n WARD BED LAYOUT ");

        for (int row = 0; row < beds.length; row++) {

            for (int column = 0;
                 column < beds[row].length;
                 column++) {

                System.out.printf(
                        "%-12s",
                        beds[row][column]
                );
            }

            System.out.println();
        }
    }

    // Display available beds

    public void displayAvailableBeds() {

        System.out.println("\n===== AVAILABLE BEDS =====");

        boolean found = false;

        for (int row = 0; row < beds.length; row++) {

            for (int column = 0;
                 column < beds[row].length;
                 column++) {

                if (!beds[row][column].contains(":")) {

                    System.out.println(
                            beds[row][column]
                    );

                    found = true;
                }
            }
        }

        if (!found) {

            System.out.println("No beds available.");
        }
    }

    // Display occupied beds

    public void displayOccupiedBeds() {

        System.out.println("\n===== OCCUPIED BEDS =====");

        boolean found = false;

        for (int row = 0; row < beds.length; row++) {

            for (int column = 0;
                 column < beds[row].length;
                 column++) {

                if (beds[row][column].contains(":")) {

                    System.out.println(
                            beds[row][column]
                    );

                    found = true;
                }
            }
        }

        if (!found) {

            System.out.println("No beds occupied.");
        }
    }

    
    // REPORTS
    

    // Total patients

    public int getTotalPatients() {

        return patients.size();
    }

    // Occupied beds

    public int getOccupiedBeds() {

        int count = 0;

        for (int row = 0; row < beds.length; row++) {

            for (int column = 0;
                 column < beds[row].length;
                 column++) {

                if (beds[row][column].contains(":")) {

                    count++;
                }
            }
        }

        return count;
    }

    // Available beds

    public int getAvailableBeds() {

        return 20 - getOccupiedBeds();
    }

    // Occupancy percentage

    public double getOccupancyPercentage() {

        return (getOccupiedBeds() / 20.0) * 100;
    }

    // Hospital report

    public void generateReport() {

        
        System.out.println("       HOSPITAL REPORT");
       

        System.out.println(
                "Total patients: "
                + getTotalPatients()
        );

        System.out.println(
                "Occupied beds: "
                + getOccupiedBeds()
        );

        System.out.println(
                "Available beds: "
                + getAvailableBeds()
        );

        System.out.printf(
                "Occupancy: %.2f%%\n",
                getOccupancyPercentage()
        );
    }

    
    // SORTING
    

    // Sort by surname

    public void sortBySurname() {

        Collections.sort(
                patients,
                Comparator.comparing(
                        patient::getLastName,
                        String.CASE_INSENSITIVE_ORDER
                )
        );
    }

    // Sort by Patient ID

    public void sortByPatientId() {

        Collections.sort(
                patients,
                Comparator.comparing(
                        patient::getPatientId,
                        String.CASE_INSENSITIVE_ORDER
                )
        );
    }
}
   
