/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.hospitalpatientadmissionsystem;

import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author rikha
 */
public class HospitalPatientAdmissionSystemTest {
    
    public HospitalPatientAdmissionSystemTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of registerPatient method.
     */
    @Test
    public void testRegisterPatient() {

        System.out.println("registerpatient");

        HospitalSystem hospital = new HospitalSystem();

        String data =
                "p001\n"
                + "John\n"
                + "Smith\n"
                + "25\n"
                + "Male\n"
                + "Flu\n"
                + "2\n";

        Scanner input = new Scanner(data);

        HospitalPatientAdmissionSystem.registerPatient(
                input, hospital
        );

        patient result =
                hospital.searchPatient("P001");

        assertNotNull(result);
        assertEquals("John", result.getFirstName());
        assertEquals("Smith", result.getLastName());
        assertEquals(25, result.getAge());
        assertEquals(PatientCategory.OUTPATIENT,
                result.getCategory());
    }

    /**
     * Test of chooseCategory method.
     */
    @Test
    public void testChooseCategory() {

        System.out.println("patientcategory");

        String data = "1\n";

        Scanner input = new Scanner(data);

        PatientCategory result =
                HospitalPatientAdmissionSystem.chooseCategory(input);

        assertEquals(
                PatientCategory.INPATIENT,
                result
        );
    }

    /**
     * Test of searchPatient method.
     */
    @Test
    public void testSearchPatient() {

        System.out.println("searchPatient");

        HospitalSystem hospital =
                new HospitalSystem();

        patient p = new patient(
                "P002",
                "Mary",
                "Jones",
                30,
                "Female",
                "Headache",
                PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(p);

        Scanner input =
                new Scanner("P002\n");

        HospitalPatientAdmissionSystem.searchPatient(
                input, hospital
        );

        patient result =
                hospital.searchPatient("P002");

        assertNotNull(result);
        assertEquals(
                "Mary",
                result.getFirstName()
        );
    }

    /**
     * Test of updatePatient method.
     */
    @Test
    public void testUpdatePatient() {

        System.out.println("updatePatient");

        HospitalSystem hospital =
                new HospitalSystem();

        patient p = new patient(
                "P003",
                "Peter",
                "Mokoena",
                40,
                "Male",
                "Fever",
                PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(p);

        String data =
                "P003\n"
                + "Peter\n"
                + "Mokoena\n"
                + "41\n"
                + "Male\n"
                + "Flu\n"
                + "2\n";

        Scanner input =
                new Scanner(data);

        HospitalPatientAdmissionSystem.updatePatient(
                input, hospital
        );

        patient result =
                hospital.searchPatient("P003");

        assertNotNull(result);
        assertEquals(41, result.getAge());
        assertEquals(
                "Flu",
                result.getMedicalCondition()
        );
    }

    /**
     * Test of deletePatient method.
     */
    @Test
    public void testDeletePatient() {

        System.out.println("deletePatient");

        HospitalSystem hospital =
                new HospitalSystem();

        patient p = new patient(
                "P004",
                "David",
                "Molefe",
                35,
                "Male",
                "Cold",
                PatientCategory.OUTPATIENT
        );

        hospital.registerPatient(p);

        Scanner input =
                new Scanner("P004\n");

        HospitalPatientAdmissionSystem.deletePatient(
                input, hospital
        );

        assertNull(
                hospital.searchPatient("P004")
        );
    }

    /**
     * Test of allocateBed method.
     */
    @Test
    public void testAllocateBed() {

        System.out.println("allocateBed");

        HospitalSystem hospital =
                new HospitalSystem();

        inpatient p = new inpatient(
                "P005",
                "Sarah",
                "Mabena",
                28,
                "Female",
                "Injury",
                "Ward 1",
                "Not Allocated"
        );

        hospital.registerPatient(p);

        String data =
                "P005\n"
                + "B01\n";

        Scanner input =
                new Scanner(data);

        HospitalPatientAdmissionSystem.allocateBed(
                input, hospital
        );

        assertEquals(
                "B01",
                p.getBedNumber()
        );
    }

    /**
     * Test of releaseBed method.
     */
    @Test
    public void testReleaseBed() {

        System.out.println("releaseBed");

        HospitalSystem hospital =
                new HospitalSystem();

        inpatient p = new inpatient(
                "P006",
                "James",
                "Nkosi",
                45,
                "Male",
                "Injury",
                "Ward 2",
                "Not Allocated"
        );

        hospital.registerPatient(p);

        hospital.allocateBed(
                "P006",
                "Not Allocated"
        );

        Scanner input =
                new Scanner("Not Allocated");

        HospitalPatientAdmissionSystem.releaseBed(
                input, hospital
        );

        assertEquals(
                "Not Allocated",
                p.getBedNumber()
        );
    }
}